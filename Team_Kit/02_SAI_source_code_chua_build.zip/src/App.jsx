import React from "react";

export default function App() {
  return (
    <div className="app">
      <h1>Smart Travel Gia Lai</h1>
      <p>Đây là source code React chưa build - cần chạy "npm install" và "npm run build" trước khi nộp.</p>
    </div>
  );
}
