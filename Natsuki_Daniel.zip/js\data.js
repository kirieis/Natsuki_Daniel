// Database của các điểm du lịch tại Gia Lai
const PLACES = [
  {
    id: "bien-ho",
    name: "Biển Hồ (T'Nưng)",
    nameEn: "T'Nung Lake (Bien Ho)",
    img: "images/bien-ho.jpg",
    tags: ["nature", "check-in", "family"],
    desc: "Được ví như 'Đôi mắt Pleiku', hồ nước ngọt tự nhiên nằm trên miệng núi lửa đã ngưng hoạt động từ triệu năm trước. Mặt nước phẳng lặng xanh ngắt quanh năm, bao quanh bởi rừng thông rì rào.",
    descEn: "Known as the 'Eyes of Pleiku', this natural freshwater lake sits on a volcanic crater extinct for millions of years. Its calm, emerald water is surrounded by pine forests.",
    rating: 4.9,
    hours: "06:00 - 18:00",
    price: "10.000đ",
    priceVal: 10000,
    address: "Xã Biển Hồ, TP. Pleiku, Gia Lai",
    addressEn: "Bien Ho Commune, Pleiku City, Gia Lai",
    green: true, // Thân thiện môi trường
    x: 48, // Tọa độ giả định trên bản đồ SVG (%)
    y: 35,
    duration: 1.5, // Số giờ tham quan trung bình
    routeTime: "15 phút từ trung tâm",
    routeTimeEn: "15 mins from center",
    lat: 14.0494,
    lng: 108.0167
  },
  {
    id: "chu-dang-ya",
    name: "Núi lửa Chư Đăng Ya",
    nameEn: "Chu Dang Ya Volcano",
    img: "images/chu-dang-ya.jpg",
    tags: ["trekking", "nature", "check-in"],
    desc: "Ngọn núi lửa đã tắt hàng triệu năm, nổi tiếng với thảm thực vật trù phú. Đặc biệt vào tháng 11, sắc hoa Dã Quỳ vàng rực phủ kín khắp triền núi, thu hút đông đảo du khách phượt.",
    descEn: "An extinct volcano for millions of years, famous for its rich soil. In November, wild sunflowers bloom in brilliant gold across the slopes, attracting adventurers.",
    rating: 4.8,
    hours: "05:00 - 18:00",
    price: "Miễn phí",
    priceVal: 0,
    address: "Làng Ploi lagri, Xã Chư Đăng Ya, Huyện Chư Păh",
    addressEn: "Ploi lagri Village, Chu Dang Ya Commune, Chu Pah District",
    green: true,
    x: 52,
    y: 20,
    duration: 2.5,
    routeTime: "40 phút từ trung tâm",
    routeTimeEn: "40 mins from center",
    lat: 14.1352,
    lng: 108.0315
  },
  {
    id: "vuon-che",
    name: "Đồi chè cổ & Hàng thông trăm tuổi",
    nameEn: "Ancient Tea Hills & Century-old Pine Road",
    img: "images/vuon-che.jpg",
    tags: ["check-in", "coffee", "family", "nature"],
    desc: "Lối đi xuyên qua hàng thông cổ thụ xanh mướt dẫn thẳng vào đồi chè cổ hơn trăm tuổi. Không khí mát lành thoảng hương chè non, địa điểm chụp hình cưới và sống ảo hot bậc nhất.",
    descEn: "A road lined with giant ancient pine trees leading directly to ancient tea hills. The cool air is filled with fresh tea scent, a top spot for wedding and scenic photos.",
    rating: 4.7,
    hours: "Tự do",
    price: "Miễn phí",
    priceVal: 0,
    address: "Huyện Chư Păh, Gia Lai",
    addressEn: "Chu Pah District, Gia Lai",
    green: true,
    x: 45,
    y: 28,
    duration: 2.0,
    routeTime: "20 phút từ trung tâm",
    routeTimeEn: "20 mins from center",
    lat: 14.0725,
    lng: 107.9944
  },
  {
    id: "thac-phu-cuong",
    name: "Thác Phú Cường",
    nameEn: "Phu Cuong Waterfall",
    img: "images/thac-phu-cuong.jpg",
    tags: ["nature", "trekking"],
    desc: "Ngọn thác hùng vĩ đổ từ độ cao 45m xuống lòng suối đá, bọt tung trắng xóa như dải lụa khổng lồ giữa núi rừng Tây Nguyên. Có cầu treo để ngắm thác từ góc nhìn tuyệt đẹp.",
    descEn: "A majestic 45m waterfall cascading down to a rocky stream, forming a giant white silk ribbon in the Central Highlands forest. Includes a suspension bridge with beautiful views.",
    rating: 4.6,
    hours: "07:30 - 17:00",
    price: "40.000đ",
    priceVal: 40000,
    address: "Xã Dun, Huyện Chư Sê, Gia Lai",
    addressEn: "Dun Commune, Chu Se District, Gia Lai",
    green: true,
    x: 55,
    y: 80,
    duration: 2.0,
    routeTime: "50 phút từ trung tâm",
    routeTimeEn: "50 mins from center",
    lat: 13.6842,
    lng: 108.1250
  },
  {
    id: "lang-jrai",
    name: "Làng du lịch văn hóa Jrai",
    nameEn: "Jrai Cultural Tourism Village",
    img: "images/lang-jrai.jpg",
    tags: ["culture", "family", "food"],
    desc: "Điểm giao lưu văn hóa đặc sắc bản địa. Du khách được chiêm ngưỡng nhà rông cao vút, xem trình diễn cồng chiêng Tây Nguyên, tìm hiểu tượng nhà mồ và thưởng thức ẩm thực truyền thống.",
    descEn: "A unique cultural interaction center. Visitors can admire towering communal houses (Nha Rong), watch gong dance performances, learn about tomb statues, and taste ethnic food.",
    rating: 4.7,
    hours: "08:00 - 21:00",
    price: "80.000đ (Bao gồm nước uống)",
    priceVal: 80000,
    address: "Huyện Ia Grai, Gia Lai",
    addressEn: "Ia Grai District, Gia Lai",
    green: false,
    x: 20,
    y: 40,
    duration: 3.0,
    routeTime: "30 phút từ trung tâm",
    routeTimeEn: "30 mins from center",
    lat: 14.0250,
    lng: 107.8200
  },
  {
    id: "phong-nguyen",
    name: "Phố ẩm thực đêm Pleiku",
    nameEn: "Pleiku Night Food Street",
    img: "images/phong-nguyen.jpg",
    tags: ["food", "check-in"],
    desc: "Khu chợ đêm sầm uất ngập tràn hương vị đặc sản phố núi. Nơi bạn thưởng thức Phở khô 2 tô trứ danh, lụi nướng chấm tương me, cơm lam gà nướng bazan cùng các thức uống thảo mộc ấm nóng.",
    descEn: "A bustling night market filled with highland flavors. Taste the famous 2-bowl dry pho, grilled meat skewers with tamarind sauce, bamboo tube rice with grilled chicken, and warm herbal tea.",
    rating: 4.6,
    hours: "17:00 - 23:30",
    price: "Theo món ăn",
    priceVal: 150000, // Chi phí ước tính trung bình
    address: "Đường Phùng Hưng, Phường Hội Thương, TP. Pleiku",
    addressEn: "Phung Hung Street, Hoi Thuong Ward, Pleiku City",
    green: false,
    x: 50,
    y: 50,
    duration: 2.0,
    routeTime: "Trung tâm thành phố",
    routeTimeEn: "City center",
    lat: 13.9782,
    lng: 108.0069
  },
  {
    id: "chua-minh-thanh",
    name: "Chùa Minh Thành",
    nameEn: "Minh Thanh Pagoda",
    img: "images/bien-ho.jpg", // Sử dụng fallback ảnh có sẵn
    tags: ["culture", "check-in"],
    desc: "Ngôi chùa có kiến trúc độc đáo tựa như những ngôi đền thần thoại Nhật Bản nhưng đậm nét văn hóa Phật giáo Việt Nam với tháp đỉnh vàng chín tầng lộng lẫy in bóng bên hồ nước tịnh tâm.",
    descEn: "A pagoda with unique architecture resembling Japanese shrines but rich in Vietnamese Buddhist culture. Features a gorgeous 9-story golden peak tower reflected in a serene pond.",
    rating: 4.9,
    hours: "07:00 - 18:30",
    price: "Miễn phí",
    priceVal: 0,
    address: "Số 348 Nguyễn Viết Xuân, Phường Hội Phú, TP. Pleiku",
    addressEn: "348 Nguyen Viet Xuan, Hoi Phu Ward, Pleiku City",
    green: false,
    x: 53,
    y: 53,
    duration: 1.5,
    routeTime: "5 phút từ trung tâm",
    routeTimeEn: "5 mins from center",
    lat: 13.9644,
    lng: 108.0195
  },
  {
    id: "quang-truong",
    name: "Quảng trường Đại Đoàn Kết",
    nameEn: "Dai Doan Ket Square",
    img: "images/lang-jrai.jpg", // Fallback ảnh có sẵn
    tags: ["culture", "check-in", "family"],
    desc: "Được xem là trái tim của thành phố Pleiku, nơi đặt tượng đài Chủ tịch Hồ Chí Minh bằng đồng lớn nhất Việt Nam. Khuôn viên rộng xanh mát với 54 cột đá bazan tượng trưng cho các dân tộc.",
    descEn: "Considered the heart of Pleiku, featuring the largest bronze statue of President Ho Chi Minh in Vietnam. The park is vast and green with 54 basalt stone pillars symbolizing the ethnic groups.",
    rating: 4.8,
    hours: "Tự do",
    price: "Miễn phí",
    priceVal: 0,
    address: "Phường Tây Sơn, TP. Pleiku, Gia Lai",
    addressEn: "Tay Son Ward, Pleiku City, Gia Lai",
    green: true,
    x: 48,
    y: 47,
    duration: 1.0,
    routeTime: "Tại trung tâm thành phố",
    routeTimeEn: "In the city center",
    lat: 13.9822,
    lng: 108.0078
  }
];

// Thời tiết giả định Gia Lai (Theo mùa / Ngày thực tế)
const WEATHER_DATA = {
  sunny: {
    status: "Nắng ráo, trời mát mẻ",
    statusEn: "Sunny & pleasantly cool",
    temp: "24°C",
    icon: "☀️",
    advice: "Thời tiết hoàn hảo cho hoạt động ngoài trời như trekking núi lửa Chư Đăng Ya và ngắm cảnh Thác Phú Cường.",
    adviceEn: "Perfect weather for outdoor activities like climbing Chu Dang Ya volcano and sightseeing Phu Cuong Waterfall."
  },
  rainy: {
    status: "Mưa rải rác vài nơi",
    statusEn: "Scattered showers",
    temp: "21°C",
    icon: "🌧️",
    advice: "Khuyến nghị ưu tiên các điểm văn hóa trong nhà như Chùa Minh Thành, thưởng thức cà phê phin hoặc khám phá Phố ẩm thực đêm Pleiku.",
    adviceEn: "Recommended to visit indoor cultural sights like Minh Thanh Pagoda, enjoy hot drip coffee, or explore Pleiku Night Food Street."
  }
};

// Danh sách Huy hiệu Gamification (Gia Lai Explorer Quest)
const TOUR_BADGES = [
  {
    id: "nature-lover",
    name: "🌿 Chúa Tể Thác Nước",
    nameEn: "Waterfall Lord",
    desc: "Khám phá các địa danh thiên nhiên hùng vĩ tại Gia Lai.",
    descEn: "Explore majestic natural sights in Gia Lai.",
    condition: "nature"
  },
  {
    id: "culture-explorer",
    name: "🏛️ Đại Sứ Cồng Chiêng",
    nameEn: "Gong Ambassador",
    desc: "Tìm hiểu văn hóa dân tộc Jrai độc đáo.",
    descEn: "Learn about the unique Jrai ethnic culture.",
    condition: "culture"
  },
  {
    id: "foodie",
    name: "🍲 Bậc Thầy Phở Khô",
    nameEn: "Dry Pho Master",
    desc: "Trải nghiệm văn hóa ẩm thực đặc sản phố núi.",
    descEn: "Experience the highland specialty culinary culture.",
    condition: "food"
  },
  {
    id: "trekker",
    name: "🥾 Phượt Thủ Chư Đăng Ya",
    nameEn: "Chu Dang Ya Conqueror",
    desc: "Thử thách bản thân với trekking địa hình dốc núi lửa.",
    descEn: "Challenge yourself with trekking on volcano terrains.",
    condition: "trekking"
  },
  {
    id: "eco-traveler",
    name: "💚 Dấu Chân Xanh",
    nameEn: "Green Footprint",
    desc: "Lập lịch trình ưu tiên bảo vệ môi trường (bật chế độ Du Lịch Xanh).",
    descEn: "Generate an eco-friendly itinerary (turn on Green Travel mode).",
    condition: "green"
  }
];

// Cấu hình chatbot đa ngôn ngữ và phản hồi thông minh (Rule-based để dự phòng)
const CHAT_TEMPLATES = {
  vi: {
    welcome: "Xin chào! Tôi là Trợ lý AI Du lịch Thông minh Gia Lai. Bạn có muốn đổi điểm đến, giảm thời gian đi bộ, hỏi thông tin ẩm thực, hay thêm địa điểm check-in sống ảo không? Hãy nhập yêu cầu của bạn bên dưới hoặc click các nút gợi ý nhé!",
    thinking: "AI đang suy nghĩ...",
    noApiKeyWarning: "⚠️ Hiện chưa cấu hình API Key thật. AI đang hoạt động ở chế độ Dự phòng thông minh (Rule-based). Bạn có thể thêm Gemini API Key ở nút Cài đặt ⚙️ trên góc màn hình để kích hoạt AI thật.",
    notext: "Vui lòng nhập nội dung tin nhắn.",
    fallbackResponse: "Tôi đã tiếp nhận yêu cầu của bạn. Tôi đã cập nhật lịch trình gợi ý dựa trên thay đổi này. Bạn có muốn hỏi thêm gì nữa không?",
    responses: [
      {
        keys: ["không thích trekking", "ít đi bộ", "mệt", "nhẹ nhàng", "lười đi bộ"],
        reply: "Đã hiểu! Tôi đã điều chỉnh lịch trình bằng cách thay thế hoạt động trekking leo Núi lửa Chư Đăng Ya và đi bộ Thác Phú Cường bằng chuyến tham quan nhẹ nhàng tại Chùa Bửu Minh, chụp ảnh Hàng thông cổ thụ trăm tuổi và vãn cảnh Chùa Minh Thành bình yên.",
        action: "reduce_trekking"
      },
      {
        keys: ["chụp ảnh", "sống ảo", "check-in", "đẹp", "ảnh đẹp", "view đẹp"],
        reply: "Gợi ý các điểm check-in siêu đẹp cho bạn: Hàng thông trăm tuổi xanh mướt, đồi chè Biển Hồ thơ mộng và Quảng trường Đại Đoàn Kết lộng gió. Lịch trình mới đã được chèn thêm các điểm này vào khung giờ hoàng hôn để có ánh sáng tốt nhất!",
        action: "add_checkin"
      },
      {
        keys: ["ăn gì", "ẩm thực", "món ăn", "đặc sản", "quán ngon", "phở khô", "gà nướng"],
        reply: "Đến Gia Lai bạn nhất định phải thử: Phở khô 2 tô Pleiku (ăn kèm chén nước súp đậm đà), Cơm lam gà nướng bazan, bò một nắng chấm muối kiến vàng dai ngọt, lá mì xào cà đắng. Tôi đã cập nhật bữa tối tại Phố ẩm thực đêm Pleiku để bạn thỏa thích thưởng thức!",
        action: "add_food"
      },
      {
        keys: ["văn hóa", "lịch sử", "nhà rông", "cồng chiêng", "dân tộc", "tượng mồ"],
        reply: "Tôi đã bổ sung trải nghiệm giao lưu văn hóa tại Làng du lịch Jrai để bạn thưởng thức múa cồng chiêng, chiêm ngưỡng nhà rông truyền thống và nghe nghệ nhân kể sử thi Tây Nguyên dưới mái nhà chung.",
        action: "add_culture"
      },
      {
        keys: ["du lịch xanh", "bảo vệ môi trường", "sinh thái", "tiết kiệm co2", "eco"],
        reply: "Tuyệt vời! Tôi đã chuyển lịch trình của bạn sang chế độ Xanh. Các điểm đến xa trung tâm đã được tối ưu hóa đường đi để giảm phát thải khí thải, ưu tiên ăn uống tại homestay địa phương và đi bộ dưới tán rừng sinh thái.",
        action: "enable_green"
      }
    ]
  },
  en: {
    welcome: "Hello! I am your Gia Lai Smart AI Travel Assistant. Would you like to adjust your destinations, reduce walking activities, ask about culinary tips, or add beautiful photo check-ins? Just type below or click a quick prompt!",
    thinking: "AI is thinking...",
    noApiKeyWarning: "⚠️ Real API Key is not configured yet. Running in smart fallback mode (Rule-based). You can add a Gemini API Key in the Settings ⚙️ icon at the top corner to enable real LLM intelligence.",
    notext: "Please enter a message.",
    fallbackResponse: "I have noted your request. I updated the generated itinerary based on this choice. Do you have any other questions?",
    responses: [
      {
        keys: ["no trekking", "less walking", "tired", "easy", "gentle", "lazy"],
        reply: "Understood! I updated the itinerary by replacing the trekking at Chu Dang Ya Volcano and hiking at Phu Cuong Waterfall with a peaceful stroll along the Century-old Pine Road, tea tasting at Bien Ho Tea Hills, and visiting Minh Thanh Pagoda.",
        action: "reduce_trekking"
      },
      {
        keys: ["photo", "check-in", "beautiful", "instagram", "selfie", "nice view"],
        reply: "Here are the top photo spots added for you: The green Century-old Pine Road, scenic Bien Ho Tea Hills, and the wind-swept Dai Doan Ket Square. I scheduled these during golden hour for the best photoshoot lighting!",
        action: "add_checkin"
      },
      {
        keys: ["eat", "food", "specialty", "restaurant", "dry pho", "chicken", "cơm lam"],
        reply: "Must-try foods in Gia Lai: Pleiku 2-bowl dry pho (served with rich broth), bamboo-tube rice with grilled free-range chicken, sun-dried beef with weaver ant salt, and bitter eggplant stir-fried with cassava leaves. I've pinned a dinner stop at Pleiku Night Food Street!",
        action: "add_food"
      },
      {
        keys: ["culture", "history", "communal", "gong", "ethnic", "jrai"],
        reply: "I have added a rich cultural interaction experience at the Jrai Village, where you can watch Gong performances, learn about communal house architecture, and interact with local weavers.",
        action: "add_culture"
      },
      {
        keys: ["green travel", "eco", "environment", "sustainable", "co2"],
        reply: "Excellent! I have toggled your itinerary to Eco-Travel Mode. Destinations are optimized for shortest transit paths to reduce emissions, emphasizing local homestays and eco-friendly trekking routes.",
        action: "enable_green"
      }
    ]
  }
};
